# Breakout (Python / Pygame)

A small Breakout (brick‑breaking) game in Python using Pygame, structured for GitHub.

## Run
```bash
pip install -r requirements.txt
python -m src.main
```

## Controls
- Left / Right: move bat
- Space: launch ball (when attached)
- R: restart (after win/lose)
- Esc: quit
