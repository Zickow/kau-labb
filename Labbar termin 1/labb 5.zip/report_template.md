# Breakout – Short Report (max 4 pages)

## 1. Introduction

## 2. Overview (class diagram)

## 3. Interesting details

## 4. Time spent

## 5. Lessons learned
